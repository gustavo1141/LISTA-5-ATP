using System;

class Program
{
    static void Main()
    {
        // Declaração das matrizes A e B com dimensões 4x6
        int[,] A = new int[4, 6];
        int[,] B = new int[4, 6];

        // Preenchimento das matrizes A e B
        PreencherMatriz(A, "A");
        PreencherMatriz(B, "B");

        // Cálculo da matriz D que é a diferença de A e B
        int[,] D = SubtrairMatrizes(A, B);

        // Exibição da matriz D
        Console.WriteLine("Matriz D (diferença de A e B):");
        ExibirMatriz(D);
    }

    // Procedimento para preencher uma matriz
    static void PreencherMatriz(int[,] matriz, string nome)
    {
        Console.WriteLine($"Digite os elementos da matriz {nome}:");
        for (int i = 0; i < matriz.GetLength(0); i++)
        {
            for (int j = 0; j < matriz.GetLength(1); j++)
            {
                Console.Write($"Elemento [{i + 1},{j + 1}]: ");
                matriz[i, j] = int.Parse(Console.ReadLine());
            }
        }
    }

    // Função para subtrair duas matrizes A e B
    static int[,] SubtrairMatrizes(int[,] A, int[,] B)
    {
        int linhas = A.GetLength(0);
        int colunas = A.GetLength(1);
        int[,] D = new int[linhas, colunas];

        for (int i = 0; i < linhas; i++)
        {
            for (int j = 0; j < colunas; j++)
            {
                D[i, j] = A[i, j] - B[i, j];
            }
        }

        return D;
    }

    // Procedimento para exibir uma matriz
    static void ExibirMatriz(int[,] matriz)
    {
        int linhas = matriz.GetLength(0);
        int colunas = matriz.GetLength(1);

        for (int i = 0; i < linhas; i++)
        {
            for (int j = 0; j < colunas; j++)
            {
                Console.Write(matriz[i, j] + "\t");
            }
            Console.WriteLine();
        }
    }
}
