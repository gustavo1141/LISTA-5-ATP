using System;

class Program
{
    static void Main()
    {
        // Declaração das matrizes A e B com dimensões 4x6
        int[,] A = new int[4, 6];
        int[,] B = new int[4, 6];

        // Preenchimento das matrizes A e B
        PreencherMatriz(A, "A");
        PreencherMatriz(B, "B");

        // Cálculo da matriz S que é a soma de A e B
        int[,] S = SomarMatrizes(A, B);

        // Exibição da matriz S
        Console.WriteLine("Matriz S (soma de A e B):");
        ExibirMatriz(S);
    }

    // Procedimento para preencher uma matriz
    static void PreencherMatriz(int[,] matriz, string nome)
    {
        Console.WriteLine($"Digite os elementos da matriz {nome}:");
        for (int i = 0; i < matriz.GetLength(0); i++)
        {
            for (int j = 0; j < matriz.GetLength(1); j++)
            {
                Console.Write($"Elemento [{i + 1},{j + 1}]: ");
                matriz[i, j] = int.Parse(Console.ReadLine());
            }
        }
    }

    // Função para somar duas matrizes A e B
    static int[,] SomarMatrizes(int[,] A, int[,] B)
    {
        int linhas = A.GetLength(0);
        int colunas = A.GetLength(1);
        int[,] S = new int[linhas, colunas];

        for (int i = 0; i < linhas; i++)
        {
            for (int j = 0; j < colunas; j++)
            {
                S[i, j] = A[i, j] + B[i, j];
            }
        }

        return S;
    }

    // Procedimento para exibir uma matriz
    static void ExibirMatriz(int[,] matriz)
    {
        int linhas = matriz.GetLength(0);
        int colunas = matriz.GetLength(1);

        for (int i = 0; i < linhas; i++)
        {
            for (int j = 0; j < colunas; j++)
            {
                Console.Write(matriz[i, j] + "\t");
            }
            Console.WriteLine();
        }
    }
}
