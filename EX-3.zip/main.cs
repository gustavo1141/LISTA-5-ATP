using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        // Declaração do vetor X de 10 elementos
        int[] X = new int[10];

        // Preenchimento do vetor X
        PreencherVetor(X);

        // Copiar valores negativos para um novo vetor
        int[] negativos = CopiarValoresNegativos(X);

        // Exibir o vetor original e o vetor de valores negativos
        Console.WriteLine("Conteúdo do vetor original:");
        ExibirVetor(X);

        Console.WriteLine("Conteúdo do vetor com valores negativos:");
        ExibirVetor(negativos);
    }

    // Procedimento para preencher o vetor com 10 elementos
    static void PreencherVetor(int[] vetor)
    {
        Console.WriteLine("Digite 10 números inteiros:");
        for (int i = 0; i < vetor.Length; i++)
        {
            Console.Write($"Elemento {i + 1}: ");
            vetor[i] = int.Parse(Console.ReadLine());
        }
    }

    // Função que copia os valores negativos de um vetor para um novo vetor
    static int[] CopiarValoresNegativos(int[] vetor)
    {
        List<int> negativosList = new List<int>();

        foreach (int valor in vetor)
        {
            if (valor < 0)
            {
                negativosList.Add(valor);
            }
        }

        return negativosList.ToArray();
    }

    // Procedimento para exibir o conteúdo de um vetor
    static void ExibirVetor(int[] vetor)
    {
        foreach (int valor in vetor)
        {
            Console.Write(valor + " ");
        }
        Console.WriteLine();
    }
}
