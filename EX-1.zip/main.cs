using System;

class Program
{
    static void Main()
    {
        // Inicializa um vetor com 20 posições
        int[] N = new int[20];

        // Lê os elementos do vetor
        Console.WriteLine("Digite 20 números inteiros:");
        for (int i = 0; i < N.Length; i++)
        {
            Console.Write($"Elemento {i + 1}: ");
            N[i] = int.Parse(Console.ReadLine());
        }

        // Inicializa o menor elemento com o primeiro valor do vetor
        int menorElemento = N[0];
        int posicao = 0;

        // Percorre o vetor para encontrar o menor elemento e sua posição
        for (int i = 1; i < N.Length; i++)
        {
            if (N[i] < menorElemento)
            {
                menorElemento = N[i];
                posicao = i;
            }
        }

        // Mostra o resultado
        Console.WriteLine($"O menor elemento de N é {menorElemento} e sua posição dentro do vetor é: {posicao}");
    }
}
