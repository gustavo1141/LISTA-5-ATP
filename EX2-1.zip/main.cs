using System;

class Program
{
    static void Main()
    {
        // Declaração do vetor de notas
        double[] notas = new double[10];

        // Preenchimento do vetor com as notas dos alunos
        PreencherNotas(notas);

        // Calcular a média e contar alunos acima da média
        CalcularMediaEContarAcimaDaMedia(notas);
    }

    // Procedimento para preencher o vetor com as notas dos alunos
    static void PreencherNotas(double[] notas)
    {
        Console.WriteLine("Digite as notas dos 10 alunos:");
        for (int i = 0; i < notas.Length; i++)
        {
            Console.Write($"Nota do aluno {i + 1}: ");
            notas[i] = double.Parse(Console.ReadLine());
        }
    }

    // Procedimento para calcular a média e contar quantos alunos tiveram nota acima da média
    static void CalcularMediaEContarAcimaDaMedia(double[] notas)
    {
        double soma = 0;
        int quantidadeAcimaDaMedia = 0;

        // Calcula a soma das notas
        for (int i = 0; i < notas.Length; i++)
        {
            soma += notas[i];
        }

        // Calcula a média
        double media = soma / notas.Length;

        // Conta quantos alunos tiveram nota acima da média
        for (int i = 0; i < notas.Length; i++)
        {
            if (notas[i] > media)
            {
                quantidadeAcimaDaMedia++;
            }
        }

        // Exibe a média e a quantidade de alunos acima da média
        Console.WriteLine($"A média da turma é: {media:F2}");
        Console.WriteLine($"Número de alunos com nota acima da média: {quantidadeAcimaDaMedia}");
    }
}
