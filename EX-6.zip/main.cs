using System;

class Program
{
    static void Main()
    {
        // Declaração do vetor para armazenar as temperaturas de outubro (31 dias)
        double[] temperaturas = new double[31];

        // Preenchimento do vetor com as temperaturas de cada dia de outubro
        PreencherTemperaturas(temperaturas);

        // Cálculo e exibição da menor e maior temperatura
        double menorTemperatura = CalcularMenorTemperatura(temperaturas);
        double maiorTemperatura = CalcularMaiorTemperatura(temperaturas);
        Console.WriteLine($"Menor temperatura: {menorTemperatura}°C");
        Console.WriteLine($"Maior temperatura: {maiorTemperatura}°C");

        // Cálculo e exibição da temperatura média
        double temperaturaMedia = CalcularTemperaturaMedia(temperaturas);
        Console.WriteLine($"Temperatura média: {temperaturaMedia:F2}°C");

        // Cálculo e exibição do número de dias com temperatura inferior à média
        int diasInferioresAMedia = ContarDiasInferioresAMedia(temperaturas, temperaturaMedia);
        Console.WriteLine($"Número de dias com temperatura inferior à média: {diasInferioresAMedia}");
    }

    // Procedimento para preencher o vetor com as temperaturas de cada dia de outubro
    static void PreencherTemperaturas(double[] temperaturas)
    {
        Console.WriteLine("Digite as temperaturas de cada dia de outubro:");
        for (int i = 0; i < temperaturas.Length; i++)
        {
            Console.Write($"Temperatura do dia {i + 1}: ");
            temperaturas[i] = double.Parse(Console.ReadLine());
        }
    }

    // Função para calcular a menor temperatura
    static double CalcularMenorTemperatura(double[] temperaturas)
    {
        double menor = temperaturas[0];
        foreach (double temp in temperaturas)
        {
            if (temp < menor)
            {
                menor = temp;
            }
        }
        return menor;
    }

    // Função para calcular a maior temperatura
    static double CalcularMaiorTemperatura(double[] temperaturas)
    {
        double maior = temperaturas[0];
        foreach (double temp in temperaturas)
        {
            if (temp > maior)
            {
                maior = temp;
            }
        }
        return maior;
    }

    // Função para calcular a temperatura média
    static double CalcularTemperaturaMedia(double[] temperaturas)
    {
        double soma = 0;
        foreach (double temp in temperaturas)
        {
            soma += temp;
        }
        return soma / temperaturas.Length;
    }

    // Função para contar o número de dias com temperatura inferior à média
    static int ContarDiasInferioresAMedia(double[] temperaturas, double media)
    {
        int contador = 0;
        foreach (double temp in temperaturas)
        {
            if (temp < media)
            {
                contador++;
            }
        }
        return contador;
    }
}
