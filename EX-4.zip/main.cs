using System;

class Program
{
    static void Main()
    {
        // Declaração dos vetores X e Y com 10 elementos cada
        int[] X = new int[10];
        int[] Y = new int[10];

        // Preenchimento dos vetores X e Y
        PreencherVetor(X, "X");
        PreencherVetor(Y, "Y");

        // Gerar um novo vetor com elementos intercalados de X e Y
        int[] Z = IntercalarVetores(X, Y);

        // Exibir os vetores X, Y e Z
        Console.WriteLine("Conteúdo do vetor X:");
        ExibirVetor(X);

        Console.WriteLine("Conteúdo do vetor Y:");
        ExibirVetor(Y);

        Console.WriteLine("Conteúdo do vetor Z (intercalado):");
        ExibirVetor(Z);
    }

    // Procedimento para preencher um vetor com 10 elementos
    static void PreencherVetor(int[] vetor, string nome)
    {
        Console.WriteLine($"Digite 10 números inteiros para o vetor {nome}:");
        for (int i = 0; i < vetor.Length; i++)
        {
            Console.Write($"Elemento {i + 1}: ");
            vetor[i] = int.Parse(Console.ReadLine());
        }
    }

    // Função que gera um novo vetor com elementos intercalados de X e Y
    static int[] IntercalarVetores(int[] X, int[] Y)
    {
        int[] Z = new int[X.Length + Y.Length];
        int j = 0;

        for (int i = 0; i < X.Length; i++)
        {
            Z[j++] = X[i]; // Posições ímpares com elementos de X
            Z[j++] = Y[i]; // Posições pares com elementos de Y
        }

        return Z;
    }

    // Procedimento para exibir o conteúdo de um vetor
    static void ExibirVetor(int[] vetor)
    {
        foreach (int valor in vetor)
        {
            Console.Write(valor + " ");
        }
        Console.WriteLine();
    }
}
