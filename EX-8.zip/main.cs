using System;

class Program
{
    static void Main()
    {
        // Declaração da matriz 4x4
        int[,] matriz = new int[4, 4];

        // Preenchimento da matriz
        PreencherMatriz(matriz);

        // Exibir os elementos da diagonal principal
        Console.WriteLine("Elementos da diagonal principal:");
        ExibirDiagonalPrincipal(matriz);

        // Calcular e exibir a soma dos elementos abaixo da diagonal principal
        int soma = SomarAbaixoDiagonalPrincipal(matriz);
        Console.WriteLine($"Soma dos elementos abaixo da diagonal principal: {soma}");
    }

    // Procedimento para preencher a matriz 4x4
    static void PreencherMatriz(int[,] matriz)
    {
        Console.WriteLine("Digite os elementos da matriz 4x4:");
        for (int i = 0; i < 4; i++)
        {
            for (int j = 0; j < 4; j++)
            {
                Console.Write($"Elemento [{i + 1},{j + 1}]: ");
                matriz[i, j] = int.Parse(Console.ReadLine());
            }
        }
    }

    // Procedimento para exibir os elementos da diagonal principal
    static void ExibirDiagonalPrincipal(int[,] matriz)
    {
        for (int i = 0; i < 4; i++)
        {
            Console.WriteLine(matriz[i, i]);
        }
    }

    // Função para somar os elementos abaixo da diagonal principal
    static int SomarAbaixoDiagonalPrincipal(int[,] matriz)
    {
        int soma = 0;
        for (int i = 1; i < 4; i++)
        {
            for (int j = 0; j < i; j++)
            {
                soma += matriz[i, j];
            }
        }
        return soma;
    }
}
