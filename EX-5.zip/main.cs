using System;

class Program
{
    static void Main()
    {
        // Sorteia 3 números entre 10 e 50
        int[] numerosSorteados = SortearNumeros();

        // Lê as tentativas do usuário até acertar um dos números sorteados
        LerTentativas(numerosSorteados);
    }

    // Função que sorteia 3 números entre 10 e 50 e retorna em um vetor
    static int[] SortearNumeros()
    {
        Random random = new Random();
        int[] numeros = new int[3];

        for (int i = 0; i < numeros.Length; i++)
        {
            numeros[i] = random.Next(10, 51);
        }

        return numeros;
    }

    // Procedimento que lê as tentativas do usuário até acertar um número sorteado
    static void LerTentativas(int[] numerosSorteados)
    {
        Console.WriteLine("Tente acertar um dos 3 números sorteados entre 10 e 50.");

        while (true)
        {
            Console.Write("Digite sua tentativa: ");
            int tentativa = int.Parse(Console.ReadLine());

            foreach (int numero in numerosSorteados)
            {
                if (tentativa == numero)
                {
                    Console.WriteLine("Parabéns! Você acertou um dos números sorteados.");
                    return;
                }
            }

            Console.WriteLine("Você não acertou. Tente novamente.");
        }
    }
}
